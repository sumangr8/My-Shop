<?php
$db=mysqli_connect("localhost","root","","myshop");



//For IP address
//function For Getting tje IP address
function getRealIpAddr()
{
	if(!empty($_SERVER['HTTP_CLIENT_IP']))
	//check ip from share internet
	{
		$ip=$_SERVER['HTTP_CLIENT_IP'];
	}
	elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
	//to check ip is pass from proxy
	{
		$ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
	}
	else
	{
		$ip=$_SERVER['REMOTE_ADDR'];
	}
	return $ip;
}
//For Category
function getcat()
{
	global $db;
	$qry=mysqli_query($db,"select * from categories");
	while($row=mysqli_fetch_array($qry))
	{
		extract($row);
		echo "<li><a href='index.php?cat_id=$cat_id'>$cat_title</a></li>";
	}
}

//Function Brand
function getbrand()
{
	global $db;
	$qry=mysqli_query($db,"select * from brands");
	while($row=mysqli_fetch_array($qry))
	{
		extract($row);
		echo "<li><a href='index.php?brand_id=$brand_id'>$brand_title</a></li>";
	}
}

//For Full Product
function getpro()
{
	if(!isset($_GET['cat_id']))
	{
		if(!isset($_GET['brand_id']))
		{
			global $db;
			$qry=mysqli_query($db,"select * from products order by rand() LIMIT 0,6");
			while($row=mysqli_fetch_array($qry))
			{
				extract($row);
				echo "<div id='single_product'>
				<h3>$product_title</h3>
				<img src='admin_area/product_images/$product_img1' width='180' height='180'>
				<p>Price $ $product_price</p>
				<a href='detail.php?product_id=$product_id' style='float:left;'>Detail</a>
				<a href='index.php?cart_id=$product_id' style='float:right;'><button>Add To Cart</button></a></div>";

			}
		}
	}
}

//When Click Category
function getcatpro()
{
	if(isset($_GET['cat_id']))
	{
			global $db;
			$cat_id=$_GET['cat_id'];
			$qry=mysqli_query($db,"select * from products where cat_id='$cat_id'");
			if($row=mysqli_num_rows($qry)==0)
			{
				echo "Not Product";
			}
			while($row=mysqli_fetch_array($qry))
			{
				extract($row);
				echo "<div id='single_product'>
				<h3>$product_title</h3>
				<img src='admin_area/product_images/$product_img1' width='180' height='180'>
				<p>Price $ $product_price</p>
				<a href='detail.php?product_id=$product_id' style='float:left;'>Detail</a>
				<a href='index.php?cart_id=$product_id' style='float:right;'><button>Add To Cart</button></a></div>";

			}
	}
}

//When Clic On brand
function getbrdpro()
{
	if(isset($_GET['brand_id']))
	{
			global $db;
			$brand_id=$_GET['brand_id'];
			$qry=mysqli_query($db,"select * from products where brand_id='$brand_id'");
			if($row=mysqli_num_rows($qry)==0)
			{
				echo "Not Product";
			}
			while($row=mysqli_fetch_array($qry))
			{
				extract($row);
				echo "<div id='single_product'>
				<h3>$product_title</h3>
				<img src='admin_area/product_images/$product_img1' width='180' height='180'>
				<p>Price $ $product_price</p>
				<a href='detail.php?product_id=$product_id' style='float:left;'>Detail</a>
				<a href='index.php?cart_id=$product_id' style='float:right;'><button>Add To Cart</button></a></div>";

			}
	}
}


//When click On cart
function cart()
{
	if(isset($_GET['cart_id']))
	{
		global $db;
		$ip=getRealIpAddr();
		$cart_id=$_GET['cart_id'];
		$qry=mysqli_query($db,"select * from cart where ip_add='$ip' AND p_id='$cart_id'");
		if($row=mysqli_num_rows($qry)>0)
		{
			echo "";
		}
		else
		{
			$qry1=mysqli_query($db,"insert into cart (p_id,ip_add) values ('$cart_id','$ip')");
			if($qry1)
			{
				echo "<script>window.open('index.php','_self')</script>";
			}
		}
	}
}

//show total cart item
function item()
{
	if(isset($_GET['cart_id']))
	{
		global $db;
		$ip=getRealIpAddr();
		$qry=mysqli_query($db,"select * from cart where ip_add='$ip'");
		$row=mysqli_num_rows($qry);
	}
	else
	{
		global $db;
		$ip=getRealIpAddr();
		$qry=mysqli_query($db,"select * from cart where ip_add='$ip'");
		$row=mysqli_num_rows($qry);
	}
	echo $row;

}

// total ammount
function total_price()
{
	global $db;
	$ip=getRealIpAddr();
	$total=0;
	$qry=mysqli_query($db, "select * from cart where ip_add='$ip'");
	while($row=mysqli_fetch_array($qry))
	{
		extract($row);
		$qry1=mysqli_query($db,"select * from products where product_id='$p_id'");
		while($row1=mysqli_fetch_array($qry1))
		{
			extract($row1);
			$product_price=array($row1['product_price']);
			$value=array_sum($product_price);
			$total +=$value;
		}
	}
	echo $total;
}
?>