<?php
@session_start();
// include("includes/db.php");
include("functions/functions.php");
?>
<?php cart(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/styles.css">
</head>
<body>
<div class="main_wrapper">
	<!--Header Start-->
	<div class="header_wrapper">
		<img src="images/head_logo.gif" height="100" width="300" style="float: left;">
		<img src="images/images.png" height="100" width="700" style="float: right;">
	</div>
	<!--Header End-->

	<!--Menu start-->
	<div id="navbar">
		<ul id="menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="all_products.php">All Product</a></li>
			<li><a href="my_account.php">My Account</a></li>
			<li><a href="user_register.php">Sign Up</a></li>
			<li><a href="cart.php">Shopping Cart</a></li>
			<li><a href="contact.php">Contect Us</a></li>
		</ul>
		<div id="form">
			<form method="get" accept="results.php" enctype="multipart/form-data">
				<input type="text" name="user_query" placeholder="Search a Product">
				<input type="submit" name="search" value="Search">
			</form>
		</div>
	</div>
	<!--Menu End-->

	<!--Main Content Area start-->
	<div class="content_wrapper">
		<!--Sidebar Start-->
		<div id="left_sidebar">
			<div id="sidebar_title">Category</div>
			<ul id="cats">
			  <?php getcat(); ?>
			</ul>

			<div id="sidebar_title">Brands </div>
			<ul id="cats">
				<?php getbrand(); ?>

			</ul>	
		</div>
		<!--Sidebar End-->

		<!--Content Area start-->
		<div id="right_content">
			<div id="headline">
				<div id="headline_content">
					<b>Welcome Gust</b>
					<b style="color: yellow;">Shoping Cart</b>
					<span>-Items- <?php item(); ?> Total Price  <?php total_price(); ?><a href="cart.php" style="color: yellow;">Go To Cart</a>
					<?php 
					if(isset($_SESSION["customer_email"]))
					{
						echo "<a href='logout.php'>Logout</a>";
					}
					else
					{
						echo "<a href='customer_login.php'>Login</a>";
					}
					?>
					</span>
				</div>
			</div><!--Close Headline-->

			<div id="products_box">
				
			<?php 
			if(!isset($_SESSION["customer_email"]))
			{
				include("customer/customer_login.php");
			}
			else
			{
				include("payment_options.php");
			}
			?>

			</div>
		</div>
		<!--Content Area End-->

	</div>
	<!-- main Content Area End-->

	<!--Footer Start-->
	<div class="footer">
		<h1 style="color: black; padding-top: 30px; text-align: center;">@Copy; 2017- By Suman Kumar</h1>
	</div>
	<!--Footer End-->
</div>
</body>
</html>