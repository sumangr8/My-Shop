<?php
@session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php

include("includes/db.php");
//include("functions/functions.php");

?>
<div align="center" style="padding: 20px;">
<h2>Payment Option For You</h2>
<?php
	$ip=getRealIpAddr();
	$qry=mysqli_query($con,"select * from customers where customer_ip='$ip'");
	$row=mysqli_fetch_array($qry);
	$customer_id=$row['customer_id'];
?>
	<b>Pay With&nbsp; <a href="http://www.paypal.com"></b><img src="images/paypal1.png" width="200" height="80"></a><b> Or<a href="order.php?c_id=<?php echo $customer_id; ?>">Pay Offline</a></b>
</div>
</body>
</html>