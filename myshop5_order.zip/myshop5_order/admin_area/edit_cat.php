<?php

$db=mysqli_connect("localhost","root","","myshop");
if(isset($_GET["edit_cat"]))
	{
		$edit_cat=$_GET['edit_cat'];
		// $qry=mysqli_query($db,"update categories set cat_title='$cat_title' where cat_id='$edit_cat'");
		$qry=mysqli_query($db,"select * from categories where cat_id='$edit_cat'");
		$row=mysqli_fetch_array($qry);
		extract($row);

	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table>
	<form method="post" action="">
		<tr>
			<td>Edit Category</td>
			<td><input type="text" name="cat_title" value="<?php echo $cat_title; ?>"></td>
			<td><input type="submit" name="update_cat" value="Update"></td>
		</tr>

	</form>
</table>
<?php
if(isset($_POST["update_cat"]))
{
	extract($_POST);
	$qry=mysqli_query($db,"update categories set cat_title='$cat_title' where cat_id='$edit_cat'");
	if($qry)
	{
		echo "<script>window.open('index.php?view_cat','_self')</script>";
	}
}

?>
</body>
</html>