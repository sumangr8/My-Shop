<?php
$db=mysqli_connect("localhost","root","","myshop");
// $delete_id=$_GET['delete_pro'];
// echo $delete_id;
//Id recive kar raha hu
if(isset($_GET["delete_pro"]))
{
	$delete_id=$_GET['delete_pro'];
	$qry=mysqli_query($db,"delete  from products where product_id='$delete_id'");
	$row=mysqli_fetch_array($qry);
	extract($row);
	if($qry)
	{
		echo "<script>alert('One product Has been Detete')</script>";
		echo "<script>window.open('index.php?view_products','_self')</script>";
	}
}