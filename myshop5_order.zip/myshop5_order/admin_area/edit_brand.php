<?php

$db=mysqli_connect("localhost","root","","myshop");
if(isset($_GET["edit_brand"]))
	{
		$edit_brand=$_GET['edit_brand'];
		// $qry=mysqli_query($db,"update categories set cat_title='$cat_title' where cat_id='$edit_cat'");
		$qry=mysqli_query($db,"select * from brands where brand_id='$edit_brand'");
		$row=mysqli_fetch_array($qry);
		extract($row);

	}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table>
	<form method="post" action="">
		<tr>
			<td>Edit Category</td>
			<td><input type="text" name="brand_title" value="<?php echo $brand_title; ?>"></td>
			<td><input type="submit" name="update_cat" value="Update"></td>
		</tr>

	</form>
</table>
<?php
if(isset($_POST["update_cat"]))
{
	extract($_POST);
	$qry=mysqli_query($db,"update brands set brand_title='$brand_title' where brand_id='$edit_brand'");
	if($qry)
	{
		echo "<script>window.open('index.php?view_brand','_self')</script>";
	}
}

?>
</body>
</html>