<?php
$db=mysqli_connect("localhost","root","","myshop");
// $delete_id=$_GET['delete_pro'];
// echo $delete_id;
//Id recive kar raha hu
if(isset($_GET["delete_brand"]))
{
	$delete_brand=$_GET['delete_brand'];
	$qry=mysqli_query($db,"delete  from brands where brand_id='$delete_brand'");
	$row=mysqli_fetch_array($qry);
	extract($row);
	if($qry)
	{
		echo "<script>alert('One product Has been Detete')</script>";
		echo "<script>window.open('index.php?view_brand','_self')</script>";
	}
}