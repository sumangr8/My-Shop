<?php
$db=mysqli_connect("localhost","root","","myshop");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php if(isset($_GET["view_products"])) { ?>
<table align="center" width="900">
<tr align="center">
	<td colspan="8"><h3>View Products.....</h3></td>
</tr>
<tr>
	<th>Product Id</th>
	<th>Title</th>
	<th>Image</th>
	<th>Price</th>
	<th>Total Sold</th>
	<th>Status</th>
	<th>Edit</th>
	<th>Delete</th>
</tr>
	<?php
	// include("include/db.php");
	$i=1;
	$qry=mysqli_query($db,"select * from products");
	while($row=mysqli_fetch_array($qry))
	{
		extract($row);

?>
<tr align="center">
	<td><?php echo $i;  ?></td>
	<td><?php echo $product_title;  ?></td>
	<td><img src="product_images/<?php echo $product_img1; ?>" width="80" height="80"></td>
	<td><?php echo $product_price;  ?></td>
	<td></td>
	<td><?php echo $status;  ?></td>
	<td><a href="index.php?edit_pro=<?php  echo $product_id; ?>">Edit</a></td>
	<td><a href="delete_pro.php?delete_pro=<?php  echo $product_id; ?>">Delete</td>
</tr>
<?php
$i++;
	}

	?>
</table>
<?php
}
else
{
	include("edit_pro.php");
}
?>	
</body>
</html>