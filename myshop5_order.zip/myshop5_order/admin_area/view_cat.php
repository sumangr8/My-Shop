<?php

$db=mysqli_connect("localhost","root","","myshop");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<table align="center" width="700" border="1">
	<form method="post" action="">
		<tr>
			<td>CAt Id</td>
			<td>Cat Title</td>
			<td>Edit</td>
			<td>Delete</td>
		</tr>
		<?php
		$i=1;
			$qry=mysqli_query($db,"select * from categories");
			while($row=mysqli_fetch_array($qry))
			{
				extract($row);
			?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $cat_title; ?></td>
				<td><a href="index.php?edit_cat=<?php echo $cat_id; ?>">Edit</td>
				<td><a href="index.php?delete_cat=<?php echo $cat_id; ?>">Delete</td>
			</tr>
			<?php
			$i++;
			}

		?>
	</form>
</table>
</body>
</html>