<?php
//@session_start();
//include("includes/db.php");


?>
<span style="background-color: red;">
	
	<form method="post" action="">
	<table width="583" bgcolor="#66CCCC"  style="float: left;">
	<tr align="center">
		<td colspan="4"><h2>Login Or Register</h2></td>
	</tr>
	<tr>
		<td align="right"><b>Your Email</b></td>
		<td><input type="text" name="customer_email" placeholder="Enter Your Email"></td>
		</tr>
		<tr>
		<td align="right"><b>Your Password</b></td>
		<td><input type="password" name="customer_pass" placeholder="Enter Your Password"></td>
		</tr>
		<tr align="center">
			<td colspan="2"><a href="forgot_pass.php">Forgot Password</a></td>
		</tr>
		<tr align="center">
		<td colspan="4"><input type="submit" name="c_login" value="Login"></td>
		</tr>

		</table>

	</form>
	<table bgcolor="#66CCCC" style="float: right;">
		<tr>
			<td><h2 style="float: right; padding: 10px;"><a href="customer_register.php">New Register Here</a></h2></td>
		</tr>
	</table>
</span>
<?php
if(isset($_POST['c_login']))
{
	extract($_POST);
	$con=mysqli_connect("localhost","root","","myshop");
	$qry=mysqli_query($con,"SELECT * FROM customers WHERE customer_email='$customer_email' AND customer_pass='$customer_pass'");
	if($qry)
	{
		session_start();
		$_SESSION["customer_email"]=$customer_email;
		echo "<script>window.open('index.php','_self')</script>";
	}
	else
	{
		echo "Wrong Password";
	}

}

?>