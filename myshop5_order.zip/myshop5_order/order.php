<?php
include("includes/db.php");
include("functions/functions.php");



if(isset($_GET["c_id"]))
{
	$customer_id=$_GET["c_id"];
}


		$ip=getRealIpAddr();
		$total=0;
		$qry=mysqli_query($db,"SELECT * FROM cart WHERE ip_add='$ip'");
		$status='Pending';
		$invoice_no=mt_rand();
		$count_pro=mysqli_num_rows($qry);
		while($row=mysqli_fetch_array($qry))
		{
			extract($row);
			$qry1=mysqli_query($db,"SELECT * FROM products WHERE product_id='$p_id'");
			while($row1=mysqli_fetch_array($qry1))
			{
				extract($row1);
				$product_price=array($row1["product_price"]);
				$value=array_sum($product_price);
				$total+=$value;

			}
			
		}



		//Get qty from cart
		$qry2=mysqli_query($db,"select * from cart where ip_add='$ip'");
		$get_qty=mysqli_fetch_array($qry2);
		$qty=$get_qty["qty"];
		if($qty==0)
		{
			$qty=1;
			$sub_total=$total;
		}
		else
		{
			$qty=$qty;
			$sub_total=$total*$qty;
		}

		$insert_order=mysqli_query($db,"INSERT INTO `customer_orders`(`customer_id`, `due_amount`, `invoice_no`, `total_products`, `order_date`, `order_status`) VALUES ('$customer_id','$sub_total','$invoice_no','$count_pro','NOW()','$status')");
		echo "<script>alert('Sucessfully submit')</script>";
		echo "<script>window.open('index.php','_self')</script>";

		$empty_cart=mysqli_query($db,"DELETE FROM `cart` WHERE ip_add='$ip'");

		$pending_order=mysqli_query($db,"INSERT INTO `pending_orders`(`customer_id`, `invoice_no`, `product_id`, `qty`, `order_status`) VALUES ('$customer_id','$invoice_no','$product_id','$qty','$status')");
?>