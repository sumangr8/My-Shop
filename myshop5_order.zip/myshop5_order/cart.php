<?php
session_start();
 include("includes/db.php");
include("functions/functions.php");
?>
<?php cart(); ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/styles.css">
</head>
<body>
<div class="main_wrapper">
	<!--Header Start-->
	<div class="header_wrapper">
		<img src="images/head_logo.gif" height="100" width="300" style="float: left;">
		<img src="images/images.png" height="100" width="700" style="float: right;">
	</div>
	<!--Header End-->

	<!--Menu start-->
	<div id="navbar">
		<ul id="menu">
			<li><a href="index.php">Home</a></li>
			<li><a href="all_products.php">All Product</a></li>
			<li><a href="my_account.php">My Account</a></li>
			<li><a href="user_register.php">Sign Up</a></li>
			<li><a href="cart.php">Shopping Cart</a></li>
			<li><a href="contact.php">Contect Us</a></li>
		</ul>
		<div id="form">
			<form method="get" accept="results.php" enctype="multipart/form-data">
				<input type="text" name="user_query" placeholder="Search a Product">
				<input type="submit" name="search" value="Search">
			</form>
		</div>
	</div>
	<!--Menu End-->

	<!--Main Content Area start-->
	<div class="content_wrapper">
		<!--Sidebar Start-->
		<div id="left_sidebar">
			<div id="sidebar_title">Category</div>
			<ul id="cats">
			  <?php getcat(); ?>
			</ul>

			<div id="sidebar_title">Brands </div>
			<ul id="cats">
				<?php getbrand(); ?>

			</ul>	
		</div>
		<!--Sidebar End-->

		<!--Content Area start-->
		<div id="right_content">
			<div id="headline">
				<div id="headline_content">
					<b>Welcome Gust</b>
					<b style="color: yellow;">Shoping Cart</b>
					<span>-Items- <?php item(); ?> Total Price  <?php total_price(); ?><a href="cart.php" style="color: yellow;">Go To Cart</a>
					<?php 
					if(isset($_SESSION["customer_email"]))
					{
						echo "<a href='logout.php'>Logout</a>";
					}
					else
					{
						echo "<a href='customer_login.php'>Login</a>";
					}
					?>
					</span>
				</div>
			</div><!--Close Headline-->

			<div id="products_box">
			<form method="post" action="">	
			<table width="800">
				<tr>
					<td>Name</td>
					<td>Qty</td>
					<td>Price</td>
					<td>Delete</td>
				</tr>
			
			<?php
			$ip=getRealIpAddr();
			$total=0;
			$qry=mysqli_query($db,"SELECT * FROM cart WHERE ip_add='$ip'");
			while($row=mysqli_fetch_array($qry))
			{
			extract($row);
			$qry1=mysqli_query($db,"SELECT * FROM products WHERE product_id='$p_id'");
			while($row1=mysqli_fetch_array($qry1))
			{
				extract($row1);
				$single_price=$row1["product_price"];
				$product_price=array($row1["product_price"]);
				$value=array_sum($product_price);
				$total+=$value;
				?>
				<tr>
					<td><?php echo $product_title; ?><br/>
					<img src="admin_area/product_images/<?php echo $product_img1 ?>" width="80" height="80"></td>
					<td><input type="text" name="qty" value="<?php echo $qty; ?>" style='width:20px;'></td>
					<td><?php echo $single_price; ?></td>
					<td><a href="delete.php?cart_id=<?php echo $p_id; ?>">Delete</a></td>
				</tr>
			<?php	

			}

			}
			?>
			<tr>
				<td colspan="3" align="right">Price:-<?php echo $total; ?></td>
			</tr>
			<tr>
				<td><a href="index.php"><button>Countinue</button></a></td>
				<td><a href="checkout.php">Checkout</a></td>
			</tr>
			</table>
			</form>
			</div>
		</div>
		<!--Content Area End-->

	</div>
	<!-- main Content Area End-->

	<!--Footer Start-->
	<div class="footer">
		<h1 style="color: black; padding-top: 30px; text-align: center;">@Copy; 2017- By Suman Kumar</h1>
	</div>
	<!--Footer End-->
</div>
</body>
</html>